from django.apps import AppConfig


class QytdbConfig(AppConfig):
    name = 'qytdb'
